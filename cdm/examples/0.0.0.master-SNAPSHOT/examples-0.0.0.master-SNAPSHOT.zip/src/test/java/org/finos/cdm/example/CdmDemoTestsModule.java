package org.finos.cdm.example;

public class CdmDemoTestsModule extends DemoCdmRuntimeModule {

	@Override
	protected void configure() {
		super.configure();
	}
}
