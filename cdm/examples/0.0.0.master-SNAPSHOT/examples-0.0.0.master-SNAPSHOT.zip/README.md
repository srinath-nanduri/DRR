# CDM&trade; Generated Java Usage Examples

This project demonstrates functionality of the generated code artifacts of the Common Domain Model&trade; 

## Build

The project is a standard maven project. Use the below command to build and test.

```bash
mvn clean install

```
